var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__0d69cd0f._.js")
R.c("server/chunks/[root-of-the-server]__015ede88._.js")
R.c("server/chunks/1b41d_syklicollege__next-internal_server_app_favicon_ico_route_actions_07041714.js")
R.m(20224)
module.exports=R.m(20224).exports
