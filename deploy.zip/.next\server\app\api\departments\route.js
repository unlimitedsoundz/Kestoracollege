var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/departments/route.js")
R.c("server/chunks/[root-of-the-server]__7b7e1a9d._.js")
R.c("server/chunks/82946_@supabase_supabase-js_dist_index_mjs_e33e1ac2._.js")
R.c("server/chunks/[root-of-the-server]__015ede88._.js")
R.c("server/chunks/1b41d_syklicollege__next-internal_server_app_api_departments_route_actions_5d3bd961.js")
R.m(43456)
module.exports=R.m(43456).exports
