globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/66b8ce80d140a348.js",
    "static/chunks/1d2090c6489e37be.js",
    "static/chunks/146776e642733d52.js",
    "static/chunks/0eb827e1ad38b145.js",
    "static/chunks/5ffe22f70c74c309.js",
    "static/chunks/turbopack-c1cf60fd6a417933.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];