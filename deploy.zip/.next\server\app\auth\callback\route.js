var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[root-of-the-server]__c526bdfc._.js")
R.c("server/chunks/OneDrive_Documents_syklicollege_875f0bde._.js")
R.c("server/chunks/[root-of-the-server]__015ede88._.js")
R.c("server/chunks/82946_@supabase_supabase-js_dist_index_mjs_e33e1ac2._.js")
R.c("server/chunks/1b41d_syklicollege__next-internal_server_app_auth_callback_route_actions_46f2647a.js")
R.m(68101)
module.exports=R.m(68101).exports
