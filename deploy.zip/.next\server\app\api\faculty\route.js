var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/route.js")
R.c("server/chunks/[root-of-the-server]__b6242d48._.js")
R.c("server/chunks/82946_@supabase_supabase-js_dist_index_mjs_e33e1ac2._.js")
R.c("server/chunks/[root-of-the-server]__015ede88._.js")
R.c("server/chunks/1b41d_syklicollege__next-internal_server_app_api_faculty_route_actions_77f35290.js")
R.m(23328)
module.exports=R.m(23328).exports
