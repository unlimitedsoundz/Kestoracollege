var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/housing/assign-room/route.js")
R.c("server/chunks/[root-of-the-server]__ac248155._.js")
R.c("server/chunks/OneDrive_Documents_syklicollege_875f0bde._.js")
R.c("server/chunks/[root-of-the-server]__6fa5a350._.js")
R.c("server/chunks/82946_@supabase_supabase-js_dist_index_mjs_e33e1ac2._.js")
R.c("server/chunks/2b89b__next-internal_server_app_api_admin_housing_assign-room_route_actions_d5d27f27.js")
R.m(46140)
module.exports=R.m(46140).exports
