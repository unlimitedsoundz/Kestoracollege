var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__c58b2070._.js")
R.c("server/chunks/82946_next_da0ab729._.js")
R.c("server/chunks/[root-of-the-server]__015ede88._.js")
R.c("server/chunks/82946_@supabase_supabase-js_dist_index_mjs_e33e1ac2._.js")
R.c("server/chunks/1b41d_syklicollege__next-internal_server_app_api_events_route_actions_e968b793.js")
R.m(90104)
module.exports=R.m(90104).exports
